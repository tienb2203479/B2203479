<?php
$conn = new mysqli("localhost", "root", "", "qlsv");
if ($conn->connect_error) {
    die("Connection failed");
}

$sql = "SELECT id, name_major FROM major";
$result = $conn->query($sql);
?>
<!DOCTYPE HTML>
<html>  
<body>

<form action="luu.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
Birthday: <input type="date" name="birth"><br>
Chuyên ngành:
    <select name="major_id" required>
        <option value="">-- Chọn chuyên ngành --</option>
        <?php
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['id']}'>
                        {$row['id']} - {$row['name_major']}
                      </option>";
            }
        }
        ?>
    </select><br><br>
<input type="submit">
</form>

</body>
</html>
