<?php
$conn = new mysqli("localhost", "root", "", "qlsv");
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

$name_major = $_POST['name_major'];

$sql = "INSERT INTO major (name_major) VALUES (?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $name_major);

if ($stmt->execute()) {
    header("Location: major_index.php"); 
    exit();
} else {
    echo "Lỗi thêm chuyên ngành";
}

$stmt->close();
$conn->close();
?>
