<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM student";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {

    /* =======================
       CÁCH 1: IN ĐỐI TƯỢNG RESULT
    ======================== */
    echo "<h3>Cách 1: print_r(\$result)</h3>";
    print_r($result);
    echo "<hr>";

    /* =======================
       CÁCH 2: fetch_assoc()
    ======================== */
    echo "<h3>Cách 2: fetch_assoc()</h3>";
    while ($row = $result->fetch_assoc()) {
        echo "ID: {$row['id']} - Họ tên: {$row['fullname']} - Email: {$row['email']} - Ngày sinh: {$row['Birthday']}<br>";
    }

    $result->free_result();


    /* =======================
       CÁCH 3: fetch_all()
    ======================== */
    $result = $conn->query($sql);
    echo "<h3>Cách 3: fetch_all()</h3>";
    $rows = $result->fetch_all();
    echo "<table border='1'>
            <tr><th>ID</th><th>Họ tên</th><th>Email</th><th>Ngày sinh</th></tr>";
    foreach ($rows as $row) {
        $date = date_create($row[3]);
        echo "<tr>
                <td>$row[0]</td>
                <td>$row[1]</td>
                <td>$row[2]</td>
                <td>".$date->format('d-m-Y')."</td>
              </tr>";
    }
    echo "</table>";

    $result->free_result();


    /* =======================
       CÁCH 4: fetch_row()
    ======================== */
    $result = $conn->query($sql);
    echo "<h3>Cách 4: fetch_row()</h3>";
    echo "<table border='1'>";
    while ($row = $result->fetch_row()) {
        echo "<tr>
                <td>$row[0]</td>
                <td>$row[1]</td>
                <td>$row[2]</td>
                <td>$row[3]</td>
              </tr>";
    }
    echo "</table>";

    $result->free_result();


    /* =======================
       CÁCH 5: fetch_array()
    ======================== */
    $result = $conn->query($sql);
    echo "<h3>Cách 5: fetch_array()</h3>";
    echo "<table border='1'>";
    while ($row = $result->fetch_array()) {
        echo "<tr>
                <td>".$row['id']."</td>
                <td>".$row['fullname']."</td>
                <td>".$row['email']."</td>
                <td>".$row['Birthday']."</td>
              </tr>";
    }
    echo "</table>";

    $result->free_result();


    /* =======================
       CÁCH 6: fetch_object()
    ======================== */
    $result = $conn->query($sql);
    echo "<h3>Cách 6: fetch_object()</h3>";
    echo "<table border='1'>";
    while ($row = $result->fetch_object()) {
        echo "<tr>
                <td>$row->id</td>
                <td>$row->fullname</td>
                <td>$row->email</td>
                <td>$row->Birthday</td>
              </tr>";
    }
    echo "</table>";

} else {
    echo "0 kết quả trả về";
}

$conn->close();
?>
