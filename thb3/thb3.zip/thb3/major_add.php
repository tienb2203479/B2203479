<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Thêm chuyên ngành</title>
</head>
<body>

<h2>Thêm chuyên ngành</h2>

<form method="post" action="major_add_save.php">
    Tên chuyên ngành:
    <input type="text" name="name_major" required>
    <br><br>
    <input type="submit" value="Thêm">
</form>

</body>
</html>
